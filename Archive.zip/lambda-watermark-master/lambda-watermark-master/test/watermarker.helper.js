module.exports = {
  validOptions: {
    watermarkImagePath: './exampleWatermark.png',
    opacity: 50,
    relativeSize: 5
  },
  validImage: {
    ContentType: 'image/jpeg'
  }
}
