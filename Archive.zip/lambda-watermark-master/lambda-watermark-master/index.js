/*
 ** lambda-watermark -- Node service for AWS Lambda to apply watermark to S3 images
 ** Copyright (c) 2015 Preston L. Van Loon <preston@machinepowered.com>
 */

(function () {
  'use strict';
def add_watermark(image, text="Eternal Elegance Emporium", font_path=FONT_PATH):
    """Add a watermark text to the image."""
    try:
        font = ImageFont.truetype(font_path, 25)
        logging.info(f"Using font from {font_path}")
    except IOError:
        logging.error("Font file not found or cannot be opened. Using default font.")
        try:
            font = ImageFont.truetype(DEFAULT_FONT_PATH, 25)
            logging.info("Using default font.")
        except IOError:
            logging.error("Default font file not found. Using default PIL font.")
            font = ImageFont.load_default()

    watermark = Image.new('RGBA', image.size, (255, 255, 255, 0))
    draw = ImageDraw.Draw(watermark, 'RGBA')
    width, height = image.size
    bbox = draw.textbbox((0, 0), text, font=font)
    text_width = bbox[2] - bbox[0]
    text_height = bbox[3] - bbox[1]
    x, y = width - text_width - 10, height - text_height - 10
    draw.text((x, y), text, font=font, fill=(255, 255, 255, 128))
    return Image.alpha_composite(image.convert('RGBA'), watermark)

  module.exports = require('./lib/lambdaWrapper');

})();
