# Resource clean-up

To clean up all the resources created in this workshop: 

* Go to [Step Functions Console](https://console.aws.amazon.com/states/home), delete the `ImageProcessing` Step Functions state machine
* Go to [CloudFormation Console](https://console.aws.amazon.com/cloudformation/home), delete the `sfn-workshop-setup-webapp` CloudFormation stack
* Delete the `sfn-workshop-setup` CloudFormation stack